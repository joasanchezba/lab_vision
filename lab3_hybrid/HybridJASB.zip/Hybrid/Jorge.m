%C�digo desarrollado por Jorge S�nchez (201624511)

clc;
clear:

im1 = im2single(imread('im1.jpg'));
im2 = im2single(imread('im2.jpg'));


%*************************************************************************
%*************************************************************************
% para alinear las im�genes, se imprimieron y se midi� la posici�n en Pi-
% xeles de los ojos izuquierdos de ambas fotos, luego se verific� el re-
% sultado
%*************************************************************************
%*************************************************************************
% imshow(im1);
% figure;
% imshow(im2);

coim1=length(im1(1,:,1));
fiim1=length(im1(:,1,1));
coim2=length(im2(1,:,1));
fiim2=length(im2(:,1,1));

im1 = imcrop(im1,[1 5 coim1-10 fiim1]);
 figure;
 imshow(im1);

im2 = imcrop(im2,[10 5 coim2 fiim2]);
 figure;
 imshow(im2);


%**************************************************************************
%**************************************************************************
%*****generaci�n de im�gen h�brida.**************************************** 

cutoff_frequency = 15; 
cutoff_frequency2= 5; 
%aplicaci�n de flitfro:
filter = fspecial('Gaussian', cutoff_frequency*10+1, cutoff_frequency);
filter2 = fspecial('Gaussian', cutoff_frequency2*16+1, cutoff_frequency2);
%suma de im�genes:
low_frequencies = my_imfilter(im1, filter);
high_frequencies = im2 - my_imfilter(im2, filter2);
hybrid_image = low_frequencies + high_frequencies;
imshow (hybrid_image);
%**************************************************************************
%**************************************************************************
%creaci�n de im�genes escaladas*******************************************

scales = 5; % cuantas escalas
scale_factor = 0.5; %factor de escala
padding = 5;

original_height = size(hybrid_image,1);
num_colors = size(hybrid_image,3); %counting how many color channels the input has
output = hybrid_image;
cur_image = hybrid_image;

for i = 2:scales
    %add padding
    output = cat(2, output, ones(original_height, padding, num_colors));
    %dowsample image;
    cur_image = imresize(cur_image, scale_factor, 'bilinear');
    %pad the top and append to the output
    tmp = cat(1,ones(original_height - size(cur_image,1), size(cur_image,2), num_colors), cur_image);
    output = cat(2, output, tmp);
end

figure;

    imshow(output);





